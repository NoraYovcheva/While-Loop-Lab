﻿using System;

namespace _03.SumNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int target = int.Parse(Console.ReadLine());
            int sum = 0;

            while (true)
            {
                int currNum = int.Parse(Console.ReadLine());
                sum += currNum;
                if (target <= sum)
                {
                    break;
                }
            }
            Console.WriteLine(sum);
        }
    }
}
